package com.rullion.test;


import static org.junit.Assert.assertEquals;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import com.rulion.exception.CyclicDependencyException;
import com.rulion.service.CyclicDependancyService;

public class CyclicDependancyTest {

  public CyclicDependancyTest() {}

  CyclicDependancyService cyclicDependancyService;

  @Before
  public void setUp() {
    cyclicDependancyService = new CyclicDependancyService();
  }

  @Test
  public void PrintTaskExecutionTest1() {
    List<String> result = cyclicDependancyService.findOrder(Collections.<String>emptyList(),
        Collections.<String>emptyList());
    assertEquals("[]", result.toString());
  }

  @Test
  public void PrintTaskExecutionTest2() {
    List<String> result =
        cyclicDependancyService.findOrder(Arrays.asList("a", "b"), Collections.<String>emptyList());
    assertEquals("[a, b]", result.toString());
  }

  @Test
  public void PrintTaskExecutionTest3() {
    List<String> result =
        cyclicDependancyService.findOrder(Arrays.asList("a", "b"), Arrays.asList("a=>b"));
    assertEquals("[b, a]", result.toString());
  }

  @Test
  public void PrintTaskExecutionTest4() {
    List<String> result = cyclicDependancyService.findOrder(Arrays.asList("a", "b", "c", "d"),
        Arrays.asList("a=>b", "c=>d"));
    assertEquals("[b, a, d, c]", result.toString());
  }

  @Test
  public void PrintTaskExecutionTest5() {
    List<String> result = cyclicDependancyService.findOrder(Arrays.asList("a", "b", "c"),
        Arrays.asList("a=>b", "b=>c"));
    assertEquals("[c, b, a]", result.toString());
  }

  @Test(expected = CyclicDependencyException.class)
  public void PrintTaskExecutionTest6() {
    cyclicDependancyService.findOrder(Arrays.asList("a", "b", "c", "d"),
        Arrays.asList("a=>b", "b=>c", "c=>a"));
  }

}
