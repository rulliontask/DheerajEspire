package com.rulion.common;

public class Constants {

  public static final String STOP_VAR = "stop";
  public static final String TASK_MSG =
      "Please enter tasks and type 'stop' to stop entering values";
  public static final String DEPNDCY_MSG =
      " Please enter dependencies in format i.e. task1=>task2 means task1 depends on task2 and type 'stop' to stop entering values";
}
