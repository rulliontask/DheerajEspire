package com.rulion.service;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import com.rulion.exception.CyclicDependencyException;

public class CyclicDependancyService {

  public static String createDepandancy(String task, List<String> dependencyArray) {

    Optional<String> taskAndDep = dependencyArray.stream()
        .filter(dependency -> task.equals(dependency.split("=>")[0])).findFirst();
    return taskAndDep.isPresent() ? taskAndDep.get().split("=>")[1] : null;

  }

  public List<String> findOrder(List<String> taskArray, List<String> dependencyArray) {
    List<String> executedTasks = new LinkedList<>();

    boolean isfound = false;
    boolean isRecurrsive = false;

    for (String task : taskArray) {
      isfound = false;
      isRecurrsive = false;
      List<String> processExcecute = new LinkedList<>();
      String localVar = task;
      if (!executedTasks.contains(task)) {
        while (!isfound) {
          String dependantVar = createDepandancy(localVar, dependencyArray);
          if (processExcecute.contains(dependantVar)) {
            throw new CyclicDependencyException("Error - this is a cyclic dependency");
          }
          if (dependantVar == null) {
            isfound = true;
            if (isRecurrsive) {
              Collections.reverse(processExcecute);
            }
            processExcecute.add(task);
          } else {
            isRecurrsive = true;
            localVar = dependantVar;
            processExcecute.add(dependantVar);
          }
        }
        executedTasks.addAll(processExcecute);
      }
    }
    return executedTasks;
  }
}
