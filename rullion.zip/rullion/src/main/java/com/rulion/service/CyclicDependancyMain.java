package com.rulion.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.rulion.common.Constants;


public class CyclicDependancyMain {

  public static void main(String[] args) {

    List<String> taskArray = new ArrayList<String>();
    List<String> dependencyArray = new ArrayList<String>();
    CyclicDependancyService cyclicDependancyService = new CyclicDependancyService();

    try (Scanner sc = new Scanner(System.in)) {

      String input = "";
      System.out.println(Constants.TASK_MSG);
      while (!input.equals(Constants.STOP_VAR)) {
        input = sc.next();
        if (!input.equals(Constants.STOP_VAR)) {
          taskArray.add(input);
        }
      }

      System.out.println(Constants.DEPNDCY_MSG);

      input = "";
      while (!input.equals(Constants.STOP_VAR)) {
        input = sc.next();
        if (!input.equals(Constants.STOP_VAR)) {
          dependencyArray.add(input);
        }
      }
      System.out.println("Tasks:" + taskArray);
      System.out.println("Dependancy:" + dependencyArray);
      System.out.println("Result:" + cyclicDependancyService.findOrder(taskArray, dependencyArray));

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
