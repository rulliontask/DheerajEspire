package com.rulion.exception;

public class CyclicDependencyException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public CyclicDependencyException(String msg) {
    super(msg);
  }
}
